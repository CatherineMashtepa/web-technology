function darkmode () {
    const body = document.body
    const wasDarkMode = localStorage.getItem('darkmode') === 'true'

    localStorage.setItem('darkmode',!wasDarkMode)
    body.classList.toggle('dark-mode',!wasDarkMode)
}

document.querySelector('button').addEventListener('click',darkmode)

/*function onload() {
    document.body.classList.toggle('dark-mode',localStorage.getItem('darkmode') === 'true')
}
document.addEventListener('DOMContentLoaded', onload)

const toggleThemeBtn = document.getElementById('toggle-theve-btn')

toggleThemeBtn.addEventListener('click',() => {
    document.body.classList.add('dark')
})*/